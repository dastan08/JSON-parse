package com.krishworks.jsoninternalstg;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {


    String JSON_STRING = "{\"employee\":{\"name\":\"Aditya\",\"age\":20}}";
    String name, age;
    TextView employeeName, employeeAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // get the reference of TextView's
        employeeName = (TextView) findViewById(R.id.name);
        employeeAge = (TextView) findViewById(R.id.age);

        try {
            // get JSONObject from JSON file
            JSONObject obj = new JSONObject(JSON_STRING);
            // fetch JSONObject named employee
            JSONObject employee = obj.getJSONObject("employee");
            // get employee name and salary
            name = employee.getString("name");
            age = employee.getString("age");
            // set employee name and salary in TextView's
            employeeName.setText("Name: "+name);
            employeeAge.setText("Age: "+age);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}